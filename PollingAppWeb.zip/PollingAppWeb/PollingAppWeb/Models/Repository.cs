﻿using PollingAppWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PollingApp.Models
{
    public class Repository
    {
        private PollingAppEntities db = new PollingAppEntities();

        public PollingAppEntities Context
        {
            get
            {
                return db;
            }
        }

        public UserModel getCurrentUser()
        {
            return (UserModel)HttpContext.Current.Session["UserModel"];
        }
        /// <summary>
        /// fetch the user with given email id and password
        /// </summary>
        /// <param name="emailId"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public UserModel getUser(string emailId, string password)
        {
            tblUser user = db.tblUsers.Where(m => m.Email == emailId && password == m.Password).FirstOrDefault();
            
            if (user != null)
            {
                UserModel userModel = new UserModel();
                userModel.EmailID = user.Email;
                userModel.Name = user.Name;
                userModel.RoleID = user.RoleID;
                userModel.ID = user.ID;
                return userModel;
            }
            return null;
        }

        public UserModel getUserByEmail(string emailId)
        {
            tblUser user = db.tblUsers.Where(m => m.Email == emailId).FirstOrDefault();

            if (user != null)
            {
                UserModel userModel = new UserModel();
                userModel.EmailID = user.Email;
                userModel.Name = user.Name;
                userModel.RoleID = user.RoleID;
                userModel.ID = user.ID;
                return userModel;
            }
            return null;
        }

        public bool isUserExist(string email)
        {
            tblUser user = db.tblUsers.Where(m => m.Email == email).FirstOrDefault();

            if (user != null)
            {
               return true;
            }
            return false;
        }

        public UserModel addUser(UserModel user)
        {
            //Add user to database
            ////Start
            tblUser dbUser = new tblUser();
            dbUser.Email = user.EmailID;
            dbUser.Password = user.Password;
            dbUser.Name = user.Name;
            dbUser.RoleID = (int)Role.User;
            db.tblUsers.Add(dbUser);
            db.SaveChanges();
            ////END
            //add ID and Role ID to UserModel from DBUser
            user.ID = dbUser.ID;
            user.RoleID = dbUser.RoleID;
            //return UserModel Obj
            return user;
        }


        /// <summary>
        /// fetch all the question from the db with their choices
        /// </summary>
        /// <returns></returns>
        public List<QuestionModel> getAllQuestionList()
        {
            List<tblQuestion> questionlist= db.tblQuestions.ToList();
            List<QuestionModel> questionModelList = new List<QuestionModel>();
            foreach(tblQuestion question in questionlist){
                QuestionModel questionModel = new QuestionModel();
                List<ChoiceModel> choiceModelList = new List<ChoiceModel>();
                questionModel.ID = question.ID;
                questionModel.QuestionText = question.QuestionText;
                questionModel.IsEditable = isQuestionEditable(question.ID);
                foreach (tblChoice dbchoice in question.tblChoices)
                {
                    ChoiceModel choiceModel = new ChoiceModel();
                    choiceModel.ID = dbchoice.ChoiceID;
                    choiceModel.ChoiceText = dbchoice.ChoiceText;
                    questionModel.ChoiceList.Add(choiceModel);
                }
                questionModelList.Add(questionModel);
            }

            return questionModelList;
        }

        public QuestionModel getQuestionByID(int id)
        {
            tblQuestion dbQuestion = db.tblQuestions.Where(m => m.ID == id).FirstOrDefault();
            QuestionModel questionModel = new QuestionModel();
            questionModel.ID = dbQuestion.ID;
            questionModel.QuestionText = dbQuestion.QuestionText;
            questionModel.IsEditable = isQuestionEditable(id);

            List<ChoiceModel> choiceModelList = new List<ChoiceModel>();
            foreach (tblChoice choice in dbQuestion.tblChoices)
            {
                ChoiceModel choiceModel = new ChoiceModel();
                choiceModel.ID = choice.ChoiceID;
                choiceModel.ChoiceText = choice.ChoiceText;
                questionModel.ChoiceList.Add(choiceModel);
            }
            return questionModel;
        }

        public bool isQuestionEditable(int questionID)
        {
            bool isQuestionExistInPollResult = db.tblPollResults.Where(m => m.QuestionID == questionID).Any();
            if (isQuestionExistInPollResult)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool isQuestionVotedByUser(int questionID, int userID)
        {
            bool isQuestionVotedByUser = db.tblPollResults.Where(m => m.QuestionID == questionID && m.UserID==userID).Any();
            if (isQuestionVotedByUser)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public QuestionModel getQuestionWithVoteByIDAndUserID(int id, int userID)
        {
            tblQuestion dbQuestion = db.tblQuestions.Where(m => m.ID == id).FirstOrDefault();
            QuestionModel questionModel = new QuestionModel();
            questionModel.ID = dbQuestion.ID;
            questionModel.QuestionText = dbQuestion.QuestionText;
            questionModel.IsEditable = isQuestionEditable(id);
            List<ChoiceModel> choiceModelList = new List<ChoiceModel>();
            foreach (tblChoice choice in dbQuestion.tblChoices)
            {
                ChoiceModel choiceModel = new ChoiceModel();
                choiceModel.ID = choice.ChoiceID;
                choiceModel.ChoiceText = choice.ChoiceText;
                choiceModel.isVoted = checkWetherChoiceIsVotedByUser(choice.ChoiceID, userID);
                questionModel.ChoiceList.Add(choiceModel);
            }
            return questionModel;
        }

        public List<QuestionModel> getAllQuestionListWithVote(int userID)
        {
            List<tblQuestion> questionlist = db.tblQuestions.ToList();
            List<QuestionModel> questionModelList = new List<QuestionModel>();
            foreach (tblQuestion question in questionlist)
            {
                QuestionModel questionModel = new QuestionModel();
                List<ChoiceModel> choiceModelList = new List<ChoiceModel>();
                questionModel.ID = question.ID;
                questionModel.QuestionText = question.QuestionText;
                questionModel.IsEditable = isQuestionEditable(question.ID);
                foreach (tblChoice dbchoice in question.tblChoices)
                {
                    ChoiceModel choiceModel = new ChoiceModel();
                    choiceModel.ID = dbchoice.ChoiceID;
                    choiceModel.ChoiceText = dbchoice.ChoiceText;
                    choiceModel.isVoted = checkWetherChoiceIsVotedByUser(dbchoice.ChoiceID, userID);
                    questionModel.ChoiceList.Add(choiceModel);
                }
                questionModelList.Add(questionModel);
            }

            return questionModelList;
        }

        //check wether choice is voted for a question by a user
        public bool checkWetherChoiceIsVotedByUser(int choiceID, int userID)
        {
            bool isVoted = db.tblPollResults.Where(m => m.ChoiceID == choiceID && m.UserID == userID).Any();
            return isVoted;
        }

        //check wether choice is voted for a question by any user
        public bool checkWetherChoiceIsVoted(int choiceID)
        {
            bool isVoted = db.tblPollResults.Where(m => m.ChoiceID == choiceID).Any();
            return isVoted;
        }

        //get the choices of a question
        public List<ChoiceModel> getChoicesofQuestion(int questionID)
        {
            List<tblChoice> dbChoiceList = db.tblChoices.Where(m => m.QuestionID == questionID).ToList();
            List<ChoiceModel> choiceModelList = new List<ChoiceModel>();
            foreach (tblChoice choice in dbChoiceList)
            {
                ChoiceModel choiceModel = new ChoiceModel();
                choiceModel.ID = choice.ChoiceID;
                choiceModel.ChoiceText = choice.ChoiceText;
                choiceModel.isVoted = checkWetherChoiceIsVoted(choice.ChoiceID);
                choiceModelList.Add(choiceModel);
            }
            return choiceModelList;
        }


        // get the poll result for the question which will be shown in bar chart
        public PollResult getPollResultForQuestion(int questionID)
        {
            tblQuestion dbQuestion = db.tblQuestions.Where(m => m.ID == questionID).FirstOrDefault();
            List<tblPollResult> pollResultList = db.tblPollResults.Where(m => m.QuestionID == questionID).ToList();
            PollResult pollResultModel = new PollResult();
            pollResultModel.QuestionID = dbQuestion.ID;
            pollResultModel.QuestionText = dbQuestion.QuestionText;
            List<ChoiceModel> choiceModelList = getChoicesofQuestion(questionID);
            foreach (ChoiceModel choiceModel in choiceModelList)
            {
                ChoiceWithCount choiceWithCount = new ChoiceWithCount();
                choiceWithCount.choiceID = choiceModel.ID;
                choiceWithCount.choiceText = choiceModel.ChoiceText;
                choiceWithCount.ChoiceCount = pollResultList.Where(m => m.ChoiceID == choiceModel.ID).Count();
                pollResultModel.ChoiceWithCountList.Add(choiceWithCount);
            }
            return pollResultModel;
        }

        //add the question and choices to db
        public void addQuestion(QuestionModel questionModel, UserModel user)
        {
            //add the question to db
            tblQuestion dbQuestion = new tblQuestion();
            dbQuestion.QuestionText = questionModel.QuestionText;
            dbQuestion.CreatedBy = user.ID;
            dbQuestion.CreatedDate = DateTime.Now;
            db.tblQuestions.Add(dbQuestion);
            db.SaveChanges();

            //add choices of the question to db
            foreach(ChoiceModel choiceModel in questionModel.ChoiceList)
            {
                tblChoice dbChoice = new tblChoice();
                dbChoice.ChoiceText = choiceModel.ChoiceText;
                dbChoice.QuestionID = dbQuestion.ID;
                dbChoice.CreatedBy = user.ID;
                dbChoice.CreatedDate = DateTime.Now;
                db.tblChoices.Add(dbChoice);
            }

            db.SaveChanges();
        }

        //edit question and choice 
        public void editQuestion(QuestionModel questionModel, UserModel user)
        {
            List<tblChoice> dbChoiceList = db.tblChoices.Where(m => m.QuestionID == questionModel.ID).ToList();
            //remove old choices for the current question
            db.tblChoices.RemoveRange(dbChoiceList);

            //Update changes
            tblQuestion dbquestion = db.tblQuestions.Where(m => m.ID == questionModel.ID).FirstOrDefault();
            dbquestion.QuestionText = questionModel.QuestionText;
            dbquestion.ModifiedBy = user.ID;
            dbquestion.ModifiedDate = DateTime.Now;
            //add new choices for the question
            foreach (ChoiceModel choiceModel in questionModel.ChoiceList)
            {
                tblChoice dbChoice = new tblChoice();
                dbChoice.ChoiceText = choiceModel.ChoiceText;
                dbChoice.QuestionID = questionModel.ID;
                dbChoice.CreatedBy = user.ID;
                dbChoice.CreatedDate = DateTime.Now;
                db.tblChoices.Add(dbChoice);
            }

            db.SaveChanges();
        }

        public int? getVotedChoiceIDByUserForThisQuestion(int questionID, int userID)
        {
            return db.tblPollResults.Where(m => m.QuestionID == questionID && m.UserID == userID).Select(m => m.ChoiceID).FirstOrDefault();
        }

        
        public List<PollVotingModel> getPollVotingModelList(int userID)
        {
            List<tblQuestion> allQuestionList = db.tblQuestions.ToList();
            List<PollVotingModel> pollVotingModelList = new List<PollVotingModel>();
            foreach (tblQuestion question in allQuestionList)
            {
                PollVotingModel pollVotingModel = new PollVotingModel();
                pollVotingModel.QuestionID = question.ID;
                pollVotingModel.IsQuestionVoted = isQuestionVotedByUser(question.ID,userID);
                pollVotingModel.QuestionText = question.QuestionText;
                pollVotingModel.VotedChoiceID = getVotedChoiceIDByUserForThisQuestion(question.ID, userID);
                pollVotingModel.UserID = userID;
                foreach (tblChoice dbchoice in question.tblChoices)
                {
                    ChoiceModel choiceModel = new ChoiceModel();
                    choiceModel.ID = dbchoice.ChoiceID;
                    choiceModel.ChoiceText = dbchoice.ChoiceText;
                    choiceModel.isVoted = checkWetherChoiceIsVotedByUser(dbchoice.ChoiceID, userID);
                    pollVotingModel.ChoiceList.Add(choiceModel);
                }
                pollVotingModelList.Add(pollVotingModel);
            }
            return pollVotingModelList;
        }

        public PollResult AddVoteForPoll(int questionID, int votedChoiceID, int userID){
            tblPollResult dbPollResult = new tblPollResult();
            dbPollResult.QuestionID = questionID;
            dbPollResult.ChoiceID = votedChoiceID;
            dbPollResult.UserID = userID;
            dbPollResult.CreatedDate = DateTime.Now;
            db.tblPollResults.Add(dbPollResult);
            db.SaveChanges();
            PollResult pollResult = getPollResultForQuestion(questionID);
            return pollResult;
        }

    }
}