﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PollingApp.Models
{
    public class QuestionModel
    {
        public int ID { get; set; }
        [Required(ErrorMessage="Please provide Question Text")]
        public string QuestionText { get; set; }
        public List<ChoiceModel> ChoiceList = new List<ChoiceModel>();
        public bool IsEditable { get; set; }
    }

    public class ChoiceModel
    {
        public int ID { get; set; }
        public string ChoiceText { get; set; }
        public bool isVoted { get; set; }
    }

    public class PollResult
    {
        public int QuestionID { get; set; }
        public string QuestionText { get; set; }
        public List<ChoiceWithCount> ChoiceWithCountList = new List<ChoiceWithCount>();
    }

    public class ChoiceWithCount
    {
        public int choiceID { get; set; }
        public string choiceText { get; set; }
        public int ChoiceCount { get; set; }
    }

    public class PollVotingModel
    {
        public int QuestionID { get; set; }
        public string QuestionText { get; set; }
        public bool IsQuestionVoted{get;set;}
        public int? VotedChoiceID { get; set; }
        public int UserID { get; set; }
        public List<ChoiceModel> ChoiceList = new List<ChoiceModel>();
    }

    public class JsonModelForChoice
    {
        public string name { get; set; }
        public int y { get; set; }
    }

}