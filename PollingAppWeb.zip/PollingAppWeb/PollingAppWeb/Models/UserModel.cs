﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PollingApp.Models
{
    public class UserModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        [EmailAddress(ErrorMessage="Email id provided is invalid.")]
        public string EmailID { get; set; }
        public string Password { get; set; }
        [Compare("Password", ErrorMessage="Confirm Password should be same as Password.")]
        public string ComparePassword { get; set; }
        public int RoleID { get; set; }
    }

    public class LoginModel
    {
        [Required(ErrorMessage="Email ID is required.")]
        [EmailAddress(ErrorMessage="Email Id provided is invalid.")]
        public string LoginEmailID { get; set; }
        [Required(ErrorMessage="Password is required.")]
        public string LoginPassword { get; set; }
    }
}