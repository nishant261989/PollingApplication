﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PollingApp.Models
{
    public enum Role
    {
        Admin = 1,
        User = 2
    }
}