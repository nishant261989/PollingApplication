﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using PollingApp.Models;


namespace PollingApp.Models
{
    public class PollingAuthorizeAttribute : AuthorizeAttribute
    {
        private readonly bool _authorize;

        public PollingAuthorizeAttribute()
        {
            _authorize = false;
        }

        public PollingAuthorizeAttribute(bool authorize)
        {
            _authorize = authorize;
        }

        public override void OnAuthorization(AuthorizationContext httpContext)
        {
            Repository repo = new Repository();
            if (httpContext.HttpContext.Session == null || httpContext.HttpContext.Session["UserModel"] == null)
            {
                string emailId = httpContext.HttpContext.Request.Params["LoginEmailID"] as string;
                string password = httpContext.HttpContext.Request.Params["LoginPassword"] as string;
                UserModel user = repo.getUser(emailId, password);
                if (user != null)
                {
                    httpContext.HttpContext.Session["UserModel"] = user;
                    httpContext.Controller.TempData["UserModel"] = user;
                }
                else
                {
                    httpContext.Controller.TempData["ErrorMsg"] = "Credentials provided are invalid. Please try again.";
                    httpContext.Result = new RedirectToRouteResult(
                                    new System.Web.Routing.RouteValueDictionary { { "controller", "home" }, { "action", "index" } });
                }
            }
        }

    }

}
