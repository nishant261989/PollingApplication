﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PollingAppWeb.Startup))]
namespace PollingAppWeb
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
