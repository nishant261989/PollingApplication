﻿using PollingApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PollingAppWeb.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            if (string.IsNullOrEmpty(Convert.ToString(TempData["ErrorMsg"])) == false)
            {
                ViewBag.ErrorMsg = TempData["ErrorMsg"];
            }

            if (TempData["IsRegister"] != null)
            {
                ViewData["IsRegister"] = TempData["IsRegister"];
            }
            
            return View();
        }

        [PollingAuthorizeAttribute]
        [HttpPost]
        public ActionResult Login(LoginModel model)
        {
            UserModel currentUser = (UserModel)TempData["UserModel"];
            if (currentUser.RoleID == (int)Role.Admin)
            {
                return RedirectToAction("AdminAccount", "account");
            }
            else
            {
                return RedirectToAction("useraccount", "account");
            }
        }

        [HttpPost]
        public ActionResult Register(UserModel user)
        {
            Repository repo = new Repository();
            if (TryUpdateModel(user))
            {
                try { 
                UserModel addedUser = repo.addUser(user);
                TempData["IsRegister"] = true;
                return RedirectToAction("Index", "Home");
                    }
                catch(Exception e)
                {
                    TempData["IsRegister"] = true;
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                return View("Index");   
            }
        }

        public ActionResult isUserExist(string email)
        {
            Repository repo = new Repository();
            if (repo.isUserExist(email))
            {
                return Json(true,JsonRequestBehavior.AllowGet);
                
            }
            else
            {
                return Json(false, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}