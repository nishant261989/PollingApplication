﻿using System;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using PollingAppWeb.Models;
using PollingApp.Models;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace PollingAppWeb.Controllers
{
    [PollingAuthorizeAttribute]
    public class AccountController : Controller
    {
        private ApplicationSignInManager _signInManager;
        private ApplicationUserManager _userManager;
        private Repository repo = new Repository();
        public UserModel _currentUser;
        public AccountController()
        {
            _currentUser = repo.getCurrentUser();
        }

        public AccountController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
        {
            UserManager = userManager;
            SignInManager = signInManager;
        }

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set
            {
                _signInManager = value;
            }
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            AuthenticationManager.SignOut();
            Session["UserModel"] = null;
            return RedirectToAction("Index", "Home");
        }

        [Route("/account/admin")]
        [HttpGet]
        public ActionResult AdminAccount()
        {
            List<QuestionModel> questionList = new List<QuestionModel>();
            questionList = repo.getAllQuestionList();
            if (TempData["isSuccess"] != null)
            {
                ViewData["isSuccess"] = TempData["isSuccess"];
            }
            if (TempData["isEditSuccess"] != null)
            {
                ViewData["isEditSuccess"] = TempData["isEditSuccess"];
            }

            return View("AdminIndex", questionList);
        }

        [Route("/account/CreatePoll")]
        [HttpGet]
        public ActionResult CreatePoll()
        {
            QuestionModel model = new QuestionModel();
            return View(model);
        }

        [Route("/account/CreatePoll")]
        [HttpPost]
        public ActionResult CreatePoll(QuestionModel Model, FormCollection form)
        {
            try
            {
                ChoiceModel choiceModel = null;
                string Choice1 = Convert.ToString(form["Choice1"]);
                string Choice2 = Convert.ToString(form["Choice2"]);
                string Choice3 = Convert.ToString(form["Choice3"]);
                string Choice4 = Convert.ToString(form["Choice4"]);
                if (string.IsNullOrEmpty(Choice1) == false)
                {
                    choiceModel = new ChoiceModel();
                    choiceModel.ChoiceText = Choice1;
                    Model.ChoiceList.Add(choiceModel);
                }

                if (string.IsNullOrEmpty(Choice2) == false)
                {
                    choiceModel = new ChoiceModel();
                    choiceModel.ChoiceText = Choice2;
                    Model.ChoiceList.Add(choiceModel);
                }
                if (string.IsNullOrEmpty(Choice3) == false)
                {
                    choiceModel = new ChoiceModel();
                    choiceModel.ChoiceText = Choice3;
                    Model.ChoiceList.Add(choiceModel);
                }

                if (string.IsNullOrEmpty(Choice4) == false)
                {
                    choiceModel = new ChoiceModel();
                    choiceModel.ChoiceText = Choice4;
                    Model.ChoiceList.Add(choiceModel);
                }

                repo.addQuestion(Model, _currentUser);
                TempData["isSuccess"] = true;
            }
            catch (Exception e)
            {
                TempData["isSuccess"] = false;
                return RedirectToAction("AdminAccount");
            }
            return RedirectToAction("AdminAccount");
        }

        [Route("/account/EditPoll/{id}")]
        [HttpGet]
        public ActionResult EditPoll(int id)
        {
            QuestionModel model = repo.getQuestionByID(id);
            return View(model);
        }

        [Route("/account/EditPoll/{id}")]
        [HttpPost]
        public ActionResult EditPoll(QuestionModel Model, FormCollection form)
        {
            try
            {
                ChoiceModel choiceModel = null;
                string Choice1 = Convert.ToString(form["Choice1"]);
                string Choice2 = Convert.ToString(form["Choice2"]);
                string Choice3 = Convert.ToString(form["Choice3"]);
                string Choice4 = Convert.ToString(form["Choice4"]);
                if (string.IsNullOrEmpty(Choice1) == false)
                {
                    choiceModel = new ChoiceModel();
                    choiceModel.ChoiceText = Choice1;
                    Model.ChoiceList.Add(choiceModel);
                }

                if (string.IsNullOrEmpty(Choice2) == false)
                {
                    choiceModel = new ChoiceModel();
                    choiceModel.ChoiceText = Choice2;
                    Model.ChoiceList.Add(choiceModel);
                }
                if (string.IsNullOrEmpty(Choice3) == false)
                {
                    choiceModel = new ChoiceModel();
                    choiceModel.ChoiceText = Choice3;
                    Model.ChoiceList.Add(choiceModel);
                }

                if (string.IsNullOrEmpty(Choice4) == false)
                {
                    choiceModel = new ChoiceModel();
                    choiceModel.ChoiceText = Choice4;
                    Model.ChoiceList.Add(choiceModel);
                }

                repo.editQuestion(Model, _currentUser);
                TempData["isEditSuccess"] = true;
            }
            catch (Exception e)
            {
                TempData["isEditSuccess"] = false;
                return RedirectToAction("adminaccount");
            }
            return RedirectToAction("AdminAccount");
        }

        [Route("/account/user")]
        public ActionResult UserAccount()
        {
            List<PollVotingModel> pollVotingModelList = new List<PollVotingModel>();
            pollVotingModelList = repo.getPollVotingModelList(_currentUser.ID);
            return View("UserIndex",pollVotingModelList);
        }


        [Route("/account/saveuservote/{questionID}/{votedChoiceID}")]
        [HttpPost]
        public PartialViewResult SaveUserVote(int questionID, int votedChoiceID)
        {
            repo.AddVoteForPoll(questionID, votedChoiceID, _currentUser.ID);
            PollResult pollResult = repo.getPollResultForQuestion(questionID);
            List<JsonModelForChoice> jsonModelList = new List<JsonModelForChoice>();
            foreach (ChoiceWithCount choiceCount in pollResult.ChoiceWithCountList)
            {
                JsonModelForChoice jsonModel = new JsonModelForChoice();
                jsonModel.name = choiceCount.choiceText;
                jsonModel.y = choiceCount.ChoiceCount;
                jsonModelList.Add(jsonModel);
            }
            ViewBag.JsonForChart = jsonModelList;

            return PartialView("_PartialBarChart", pollResult);
        }

        [Route("/account/getResult/{questionID}")]
        [HttpPost]
        public PartialViewResult GetResult(int questionID)
        {
            PollResult pollResult = repo.getPollResultForQuestion(questionID);
            List<JsonModelForChoice> jsonModelList = new List<JsonModelForChoice>();
            foreach (ChoiceWithCount choiceCount in pollResult.ChoiceWithCountList)
            {
                JsonModelForChoice jsonModel = new JsonModelForChoice();
                jsonModel.name = choiceCount.choiceText;
                jsonModel.y = choiceCount.ChoiceCount;
                jsonModelList.Add(jsonModel);
            }
            ViewBag.JsonForChart = jsonModelList;

            return PartialView("_PartialBarChart", pollResult);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_userManager != null)
                {
                    _userManager.Dispose();
                    _userManager = null;
                }

                if (_signInManager != null)
                {
                    _signInManager.Dispose();
                    _signInManager = null;
                }
            }

            base.Dispose(disposing);
        }

        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        internal class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }
        #endregion
    }
}