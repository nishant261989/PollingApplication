﻿$(document).ready(function () {
    
    $("#btnRegistration").click(function () {
        var value = $("#EmailID").val();
        var name = $("#Name").val();
        var password = $("#Password").val();
        var comparePassword = $("#ComparePassword").val();
        isvalidated = true;
        if (name == null || name == '') {
            $("#NameShowError").html('Please provide Name.');
            isvalidated = false;
        }
        else {
            $("#NameShowError").hide();
        }
        if (password == null || password == '') {
            $("#PasswordShowError").html('Please provide Password.');
            isvalidated = false;
        }
        else {
            $("#PasswordShowError").hide();
            
        }
        if (comparePassword == null || comparePassword == '') {
            $("#CPShowError").html('Please confirm you password.');
            
        }
        else {
            $("#CPShowError").hide();
            
        }
        if ((password != null && password != '') && (comparePassword != null && comparePassword != '')) {
            if (password != comparePassword) {
                $("#CPShowError").html('Confirm Password field should be equal to Password.');
                isvalidated = false;
            }
            else {
                $("#CPShowError").hide();
                
            }
        }
        
        if(value == null || value == ''){
            $("#showerror").html('Email field is required.');
        }
        else {
                    $("#showerror").hide();
        }
        
        if(isvalidated){
            $("#NameShowError").hide();
            $("#showerror").hide();
            $("#PassowrdShowError").hide();
            $("#CPShowError").hide();
            var url = $("#btnRegistration").data('url');
            console.log(url);
            $.ajax({
                url: url,
                data: { email: value },
                dataType: 'json',
                contentType: 'application/json, charset=utf-8',
                type: 'GET',
                success: function (data) {
                    console.log(data);
                    if (data) {
                        $("#showerror").show();
                        $("#showerror").html('Email ID already exists.');
                        return false;
                    }
                    else {
                        console.log("ELSE");
                        $("#showerror").hide();
                        $("#formRegistration").submit();
                        return true;
                    }
                },
                complete: function (data) {

                }
            })
        }
        return false;
    });

    function isValidEmailAddress(emailAddress) {
        var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
        return pattern.test(emailAddress);
    };
});